extends Node3D
## THE LOST ROOM — mobile-friendly first-person puzzle prototype.

const WALK_SPEED := 4.2
const LOOK_SENSITIVITY := 0.003
const ROOM_HALF := 7.0

var player: CharacterBody3D
var head: Node3D
var camera: Camera3D
var flashlight: SpotLight3D
var key_item: Area3D
var door: StaticBody3D
var door_open := false
var has_key := false
var won := false
var pitch := 0.0
var move_forward := false
var move_back := false
var move_left := false
var move_right := false
var look_touch_id := -1
var last_touch_pos := Vector2.ZERO
var status_label: Label
var objective_label: Label
var interact_button: Button
var flashlight_button: Button
var start_panel: PanelContainer
var end_panel: PanelContainer
var timer_label: Label
var elapsed := 0.0
var current_level := 1
const TOTAL_LEVELS := 10
var timer_running := false
var room_root: Node3D

func _ready() -> void:
	_build_environment()
	_build_room()
	_place_level_key()
	_build_player()
	_build_ui()
	_set_status("ابحث عن المفتاح وافتح باب الخروج.")
	_update_objective()

func _build_environment() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.025, 0.04, 0.075)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.34, 0.42, 0.58)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	env.glow_enabled = true
	env.glow_intensity = 0.45
	env.glow_bloom = 0.08
	env.ssao_enabled = true
	env.ssao_radius = 2.0
	env.ssao_intensity = 1.15
	env.fog_enabled = true
	env.fog_light_color = Color(0.16, 0.22, 0.32)
	env.fog_density = 0.012
	env_node.environment = env
	add_child(env_node)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-52, -25, 0)
	light.light_energy = 0.42
	light.shadow_enabled = true
	light.directional_shadow_max_distance = 24.0
	add_child(light)

func _build_room() -> void:
	room_root = Node3D.new()
	room_root.name = "Room"
	add_child(room_root)
	_make_box(room_root, "Floor", Vector3(0, -0.25, 0), Vector3(14, 0.5, 14), Color(0.22, 0.24, 0.28), true)
	_make_box(room_root, "Ceiling", Vector3(0, 4.2, 0), Vector3(14, 0.35, 14), Color(0.12, 0.15, 0.2), true)
	_make_box(room_root, "BackWall", Vector3(0, 2, -7), Vector3(14, 4.2, 0.35), Color(0.19, 0.22, 0.29), true)
	_make_box(room_root, "LeftWall", Vector3(-7, 2, 0), Vector3(0.35, 4.2, 14), Color(0.16, 0.19, 0.26), true)
	_make_box(room_root, "RightWall", Vector3(7, 2, 0), Vector3(0.35, 4.2, 14), Color(0.16, 0.19, 0.26), true)
	# Front wall is split to leave a doorway in the middle.
	_make_box(room_root, "FrontWallLeft", Vector3(-4.5, 2, 7), Vector3(5, 4.2, 0.35), Color(0.19, 0.22, 0.29), true)
	_make_box(room_root, "FrontWallRight", Vector3(4.5, 2, 7), Vector3(5, 4.2, 0.35), Color(0.19, 0.22, 0.29), true)
	_make_box(room_root, "DoorLintel", Vector3(0, 3.65, 7), Vector3(4, 0.9, 0.35), Color(0.19, 0.22, 0.29), true)

	# Architectural trim, floor seams, and wall panels make the room feel less blocky.
	var trim_mat := Color(0.055, 0.075, 0.105)
	var brass_mat := Color(0.62, 0.39, 0.12)
	for x in [-6.65, 6.65]:
		_make_box(room_root, "WallBaseTrim", Vector3(x, 0.12, 0), Vector3(0.08, 0.24, 13.2), trim_mat, false)
	for z in [-6.65, 6.55]:
		_make_box(room_root, "WallBaseTrim", Vector3(0, 0.12, z), Vector3(13.2, 0.24, 0.08), trim_mat, false)
	for i in range(13):
		var seam := _make_box(room_root, "FloorSeam", Vector3(-6.0 + float(i), 0.008, 0), Vector3(0.018, 0.012, 13.0), Color(0.09, 0.11, 0.14), false)
	for z in [-4.8, -1.8, 1.2, 4.2]:
		_make_box(room_root, "WallInset", Vector3(-6.79, 2.0, z), Vector3(0.025, 2.8, 2.4), Color(0.11, 0.15, 0.21), false)
		_make_box(room_root, "WallInsetRim", Vector3(-6.76, 2.0, z), Vector3(0.035, 2.9, 2.5), brass_mat, false)
	# Ceiling lamps and warm pools of light; restrained light count for mobile performance.
	for lamp_pos in [Vector3(-3.8, 3.92, -3.0), Vector3(3.4, 3.92, -2.0), Vector3(0.0, 3.92, 3.2)]:
		_make_box(room_root, "CeilingLampHousing", lamp_pos, Vector3(1.0, 0.08, 0.42), Color(0.055, 0.075, 0.1), false)
		var lamp_glow := _make_box(room_root, "CeilingLampGlow", lamp_pos + Vector3(0, -0.055, 0), Vector3(0.78, 0.025, 0.25), Color(0.78, 0.88, 1.0), false)
		var lamp_light := OmniLight3D.new()
		lamp_light.position = lamp_pos + Vector3(0, -0.2, 0)
		lamp_light.light_color = Color(0.55, 0.72, 1.0)
		lamp_light.light_energy = 1.0
		lamp_light.omni_range = 5.5
		lamp_light.shadow_enabled = false
		room_root.add_child(lamp_light)

	# Main exit door.
	door = StaticBody3D.new()
	door.name = "ExitDoor"
	door.position = Vector3(0, 1.5, 6.8)
	room_root.add_child(door)
	var door_mesh := MeshInstance3D.new()
	var door_box := BoxMesh.new()
	door_box.size = Vector3(2.6, 3.0, 0.22)
	door_mesh.mesh = door_box
	door_mesh.material_override = _mat(Color(0.36, 0.19, 0.1), 0.0)
	door.add_child(door_mesh)
	var door_collision := CollisionShape3D.new()
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(2.6, 3.0, 0.22)
	door_collision.shape = door_shape
	door.add_child(door_collision)
	_make_box(room_root, "DoorHandle", Vector3(0.82, 1.45, 6.63), Vector3(0.12, 0.3, 0.1), Color(0.95, 0.68, 0.18), false)

	# Furniture and a movable-looking crate to give the room readable landmarks.
	_make_box(room_root, "Desk", Vector3(-3.8, 0.65, -2.4), Vector3(2.4, 1.3, 1.0), Color(0.34, 0.2, 0.12), true)
	_make_box(room_root, "DeskTop", Vector3(-3.8, 1.34, -2.4), Vector3(2.6, 0.12, 1.2), Color(0.48, 0.29, 0.16), true)
	for dx in [-1.0, 1.0]:
		for dz in [-0.38, 0.38]:
			_make_box(room_root, "DeskLeg", Vector3(-3.8 + dx, 0.65, -2.4 + dz), Vector3(0.12, 1.25, 0.12), Color(0.19, 0.105, 0.06), true)
	_make_box(room_root, "DeskDrawer", Vector3(-3.8, 1.02, -1.86), Vector3(1.0, 0.24, 0.08), Color(0.25, 0.13, 0.075), false)
	_make_box(room_root, "DrawerHandle", Vector3(-3.8, 1.02, -1.80), Vector3(0.22, 0.045, 0.035), brass_mat, false)
	_make_box(room_root, "Crate", Vector3(3.5, 0.65, -3.3), Vector3(1.4, 1.3, 1.4), Color(0.38, 0.25, 0.13), true)
	_make_box(room_root, "Shelf", Vector3(4.9, 1.6, 1.0), Vector3(0.45, 3.2, 2.2), Color(0.28, 0.18, 0.12), true)
	_make_box(room_root, "ShelfBoard1", Vector3(4.65, 0.8, 1.0), Vector3(0.9, 0.12, 2.1), Color(0.48, 0.3, 0.18), true)
	_make_box(room_root, "ShelfBoard2", Vector3(4.65, 1.8, 1.0), Vector3(0.9, 0.12, 2.1), Color(0.48, 0.3, 0.18), true)
	_make_box(room_root, "Rug", Vector3(0, 0.015, 0.2), Vector3(3.0, 0.04, 3.8), Color(0.13, 0.28, 0.34), false)

	# A key glowing on the desk.
	key_item = Area3D.new()
	key_item.name = "OldKey"
	key_item.position = Vector3(-3.8, 1.62, -2.4)
	room_root.add_child(key_item)
	var key_mesh := MeshInstance3D.new()
	var key_torus := TorusMesh.new()
	key_torus.inner_radius = 0.12
	key_torus.outer_radius = 0.2
	key_mesh.mesh = key_torus
	key_mesh.rotation_degrees.x = 90
	key_mesh.material_override = _mat(Color(1.0, 0.72, 0.15), 0.65)
	key_item.add_child(key_mesh)
	var key_glow := OmniLight3D.new()
	key_glow.light_color = Color(1.0, 0.58, 0.12)
	key_glow.light_energy = 0.8
	key_glow.omni_range = 2.0
	key_glow.shadow_enabled = false
	key_item.add_child(key_glow)
	var shaft := MeshInstance3D.new()
	var shaft_box := BoxMesh.new()
	shaft_box.size = Vector3(0.08, 0.42, 0.08)
	shaft.mesh = shaft_box
	shaft.position = Vector3(0, -0.22, 0)
	shaft.material_override = _mat(Color(1.0, 0.72, 0.15), 0.65)
	key_item.add_child(shaft)
	var key_collision := CollisionShape3D.new()
	var key_shape := SphereShape3D.new()
	key_shape.radius = 0.65
	key_collision.shape = key_shape
	key_item.add_child(key_collision)

	# Three glowing symbols on the wall are visual hints, not required for the first build.
	for i in range(3):
		var symbol := _make_box(room_root, "WallSymbol", Vector3(-2.0 + float(i) * 2.0, 2.4, -6.78), Vector3(0.55, 0.55, 0.06), [Color(0.15, 0.8, 1.0), Color(0.95, 0.58, 0.16), Color(0.35, 0.95, 0.55)][i], false)
		symbol.rotation_degrees.z = [0, 45, 90][i]

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "FirstPersonPlayer"
	player.position = Vector3(0, 0.05, 4.5)
	player.floor_snap_length = 0.25
	add_child(player)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.7
	collision.shape = capsule
	collision.position.y = 0.85
	player.add_child(collision)
	head = Node3D.new()
	head.name = "Head"
	head.position = Vector3(0, 1.55, 0)
	player.add_child(head)
	camera = Camera3D.new()
	camera.current = true
	camera.fov = 78
	head.add_child(camera)
	flashlight = SpotLight3D.new()
	flashlight.light_energy = 3.2
	flashlight.spot_range = 13.0
	flashlight.spot_angle = 42.0
	flashlight.shadow_enabled = true
	camera.add_child(flashlight)
	flashlight.position = Vector3(0, 0, -0.1)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var top := HBoxContainer.new()
	top.position = Vector2(18, 12)
	top.size = Vector2(924, 42)
	layer.add_child(top)
	var title := Label.new()
	title.text = "THE LOST ROOM"
	title.add_theme_font_size_override("font_size", 23)
	title.add_theme_color_override("font_color", Color(0.5, 0.88, 1.0))
	top.add_child(title)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(spacer)
	timer_label = Label.new()
	timer_label.text = "LEVEL 1/%02d  TIME 00:00" % TOTAL_LEVELS
	timer_label.add_theme_font_size_override("font_size", 19)
	timer_label.add_theme_color_override("font_color", Color.WHITE)
	top.add_child(timer_label)

	objective_label = Label.new()
	objective_label.position = Vector2(180, 55)
	objective_label.size = Vector2(600, 40)
	objective_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	objective_label.add_theme_font_size_override("font_size", 18)
	objective_label.add_theme_color_override("font_color", Color(0.96, 0.83, 0.48))
	layer.add_child(objective_label)

	status_label = Label.new()
	status_label.position = Vector2(170, 95)
	status_label.size = Vector2(620, 40)
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_font_size_override("font_size", 17)
	status_label.add_theme_color_override("font_color", Color.WHITE)
	layer.add_child(status_label)

	# Direction buttons on the left.
	var forward := _button(layer, "▲", Vector2(88, 350), Vector2(74, 64))
	forward.button_down.connect(_forward_down)
	forward.button_up.connect(_forward_up)
	var back := _button(layer, "▼", Vector2(88, 482), Vector2(74, 54))
	back.button_down.connect(_back_down)
	back.button_up.connect(_back_up)
	var left := _button(layer, "◀", Vector2(12, 416), Vector2(70, 64))
	left.button_down.connect(_left_down)
	left.button_up.connect(_left_up)
	var right := _button(layer, "▶", Vector2(168, 416), Vector2(70, 64))
	right.button_down.connect(_right_down)
	right.button_up.connect(_right_up)

	flashlight_button = _button(layer, "LIGHT ON/OFF", Vector2(742, 355), Vector2(196, 58))
	flashlight_button.pressed.connect(_toggle_flashlight)
	interact_button = _button(layer, "INTERACT", Vector2(742, 421), Vector2(196, 66))
	interact_button.pressed.connect(_interact)
	var restart := _button(layer, "RESTART", Vector2(18, 64), Vector2(112, 46))
	restart.pressed.connect(_restart)

	var hint := Label.new()
	hint.text = "حرّك الأزرار يسارًا، واسحب إصبعك على يمين الشاشة للنظر."
	hint.position = Vector2(250, 492)
	hint.size = Vector2(470, 32)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 14)
	hint.add_theme_color_override("font_color", Color(0.75, 0.82, 0.95))
	layer.add_child(hint)

	start_panel = PanelContainer.new()
	start_panel.position = Vector2(285, 155)
	start_panel.size = Vector2(390, 235)
	layer.add_child(start_panel)
	var start_box := VBoxContainer.new()
	start_box.alignment = BoxContainer.ALIGNMENT_CENTER
	start_box.add_theme_constant_override("separation", 14)
	start_panel.add_child(start_box)
	var start_title := Label.new()
	start_title.text = "THE LOST ROOM"
	start_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	start_title.add_theme_font_size_override("font_size", 30)
	start_title.add_theme_color_override("font_color", Color(0.4, 0.85, 1.0))
	start_box.add_child(start_title)
	var start_text := Label.new()
	start_text.text = "اعثر على المفتاح فوق المكتب، ثم افتح باب الخروج."
	start_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	start_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	start_box.add_child(start_text)
	var start_btn := Button.new()
	start_btn.text = "ابدأ الاستكشاف"
	start_btn.custom_minimum_size = Vector2(220, 54)
	start_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	start_btn.pressed.connect(_start_game)
	start_box.add_child(start_btn)

func _button(layer: CanvasLayer, caption: String, pos: Vector2, size_value: Vector2) -> Button:
	var b := Button.new()
	b.text = caption
	b.position = pos
	b.size = size_value
	b.custom_minimum_size = size_value
	b.add_theme_font_size_override("font_size", 19)
	b.add_theme_color_override("font_color", Color.WHITE)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.12, 0.2, 0.88)
	style.border_color = Color(0.2, 0.72, 0.9, 0.95)
	style.set_border_width_all(2)
	style.set_corner_radius_all(12)
	b.add_theme_stylebox_override("normal", style)
	var pressed := StyleBoxFlat.new()
	pressed.bg_color = Color(0.08, 0.35, 0.48, 0.96)
	pressed.border_color = Color(0.65, 0.92, 1.0)
	pressed.set_border_width_all(2)
	pressed.set_corner_radius_all(12)
	b.add_theme_stylebox_override("pressed", pressed)
	layer.add_child(b)
	return b

func _process(delta: float) -> void:
	if timer_running and not won:
		elapsed += delta
		var total := int(elapsed)
		timer_label.text = "LEVEL %02d/%02d  TIME %02d:%02d" % [current_level, TOTAL_LEVELS, int(total / 60), total % 60]
	if not won and is_instance_valid(key_item) and key_item.visible:
		key_item.rotate_y(delta * 1.4)

func _physics_process(delta: float) -> void:
	if not is_instance_valid(player) or won or not timer_running:
		return
	var input_dir := Vector2.ZERO
	if move_left:
		input_dir.x -= 1.0
	if move_right:
		input_dir.x += 1.0
	if move_forward:
		input_dir.y -= 1.0
	if move_back:
		input_dir.y += 1.0
	input_dir = input_dir.normalized()
	var direction := (player.transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	player.velocity.x = direction.x * WALK_SPEED
	player.velocity.z = direction.z * WALK_SPEED
	if not player.is_on_floor():
		player.velocity.y -= 22.0 * delta
	elif player.velocity.y < 0.0:
		player.velocity.y = 0.0
	player.move_and_slide()
	player.position.x = clamp(player.position.x, -6.2, 6.2)
	player.position.z = clamp(player.position.z, -6.2, 6.2)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x > get_viewport().get_visible_rect().size.x * 0.43:
			look_touch_id = event.index
			last_touch_pos = event.position
		elif not event.pressed and event.index == look_touch_id:
			look_touch_id = -1
	elif event is InputEventScreenDrag and event.index == look_touch_id:
		var delta_pos: Vector2 = event.position - last_touch_pos
		last_touch_pos = event.position
		_apply_look(delta_pos)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		_apply_look(event.relative)

func _apply_look(delta_pos: Vector2) -> void:
	if not timer_running or won:
		return
	player.rotate_y(-delta_pos.x * LOOK_SENSITIVITY)
	pitch = clamp(pitch - delta_pos.y * LOOK_SENSITIVITY, deg_to_rad(-75), deg_to_rad(75))
	head.rotation.x = pitch

func _interact() -> void:
	if not timer_running or won:
		return
	if is_instance_valid(key_item) and key_item.visible and player.global_position.distance_to(key_item.global_position) < 2.2:
		has_key = true
		key_item.visible = false
		_update_objective()
		_set_status("وجدت المفتاح! اقترب من الباب واضغط INTERACT.")
		return
	if is_instance_valid(door) and player.global_position.distance_to(door.global_position) < 3.0:
		if has_key:
			door_open = true
			door.visible = false
			won = true
			_update_objective()
			if current_level < TOTAL_LEVELS:
				_set_status("أحسنت! اكتملت المرحلة %d من %d." % [current_level, TOTAL_LEVELS])
				_show_level_complete()
			else:
				timer_running = false
				_set_status("مبروك! أنهيت المراحل العشر كلها!")
				_show_end()
		else:
			_set_status("الباب مقفل. ابحث عن المفتاح فوق المكتب.")
		return
	_set_status("لا يوجد شيء قريب للتفاعل معه.")

func _toggle_flashlight() -> void:
	flashlight.visible = not flashlight.visible
	flashlight_button.text = "LIGHT: ON" if flashlight.visible else "LIGHT: OFF"

func _start_game() -> void:
	start_panel.visible = false
	timer_running = true
	_set_status("استكشف الغرفة وابحث عن المفتاح.")
	_update_objective()

func _restart() -> void:
	get_tree().reload_current_scene()

func _show_level_complete() -> void:
	var panel := PanelContainer.new()
	panel.name = "LevelCompletePanel"
	panel.position = Vector2(300, 170)
	panel.size = Vector2(360, 190)
	add_child(panel)
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 12)
	panel.add_child(box)
	var title := Label.new()
	title.text = "LEVEL %02d COMPLETE!" % current_level
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", Color(0.4, 1.0, 0.72))
	box.add_child(title)
	var message := Label.new()
	message.text = "وجدت المفتاح وخرجت بنجاح!"
	message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(message)
	var next_btn := Button.new()
	next_btn.text = "المرحلة التالية  ➜"
	next_btn.custom_minimum_size = Vector2(220, 48)
	next_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	next_btn.pressed.connect(func():
		panel.queue_free()
		_next_level()
	)
	box.add_child(next_btn)

func _next_level() -> void:
	current_level += 1
	won = false
	has_key = false
	door_open = false
	move_forward = false
	move_back = false
	move_left = false
	move_right = false
	if is_instance_valid(room_root):
		room_root.queue_free()
	_build_room()
	_place_level_key()
	player.position = Vector3(0, 0.05, 4.5)
	player.rotation = Vector3.ZERO
	head.rotation = Vector3.ZERO
	pitch = 0.0
	flashlight.visible = true
	flashlight_button.text = "LIGHT ON/OFF"
	_set_status("المرحلة %d: ابحث عن المفتاح الجديد." % current_level)
	_update_objective()
	timer_running = true

func _place_level_key() -> void:
	if not is_instance_valid(key_item):
		return
	var key_positions: Array[Vector3] = [
		Vector3(-3.8, 1.62, -2.4),
		Vector3(3.5, 1.48, -3.3),
		Vector3(4.55, 1.05, 1.0),
		Vector3(-4.5, 0.55, 2.0),
		Vector3(0.0, 0.55, -4.5),
		Vector3(3.8, 0.55, 3.0),
		Vector3(-2.8, 0.55, -4.8),
		Vector3(4.5, 2.35, 1.0),
		Vector3(0.0, 0.55, 0.0),
		Vector3(-3.8, 1.62, -2.4)
	]
	key_item.position = key_positions[clampi(current_level - 1, 0, TOTAL_LEVELS - 1)]

func _show_end() -> void:
	var panel := PanelContainer.new()
	panel.position = Vector2(300, 170)
	panel.size = Vector2(360, 190)
	add_child(panel)
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 12)
	panel.add_child(box)
	var title := Label.new()
	title.text = "ALL 10 LEVELS COMPLETE!"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", Color(0.4, 1.0, 0.72))
	box.add_child(title)
	var message := Label.new()
	message.text = "أنهيت جميع المراحل العشر بنجاح!\nالوقت: %02d:%02d" % [int(elapsed / 60.0), int(elapsed) % 60]
	message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(message)
	var again := Button.new()
	again.text = "العب مجددًا"
	again.pressed.connect(_restart)
	box.add_child(again)

func _update_objective() -> void:
	if has_key:
		objective_label.text = "المرحلة %d/%d — الهدف: افتح باب الخروج" % [current_level, TOTAL_LEVELS]
	else:
		objective_label.text = "المرحلة %d/%d — الهدف: اعثر على المفتاح" % [current_level, TOTAL_LEVELS]

func _set_status(message: String) -> void:
	if is_instance_valid(status_label):
		status_label.text = message

func _mat(color_value: Color, metallic_value: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color_value
	m.metallic = metallic_value
	m.roughness = 0.62
	if color_value.r > 0.7 and color_value.g > 0.45 and color_value.b < 0.35:
		m.emission_enabled = true
		m.emission = color_value
		m.emission_energy_multiplier = 0.35
	return m

func _make_box(parent: Node, node_name: String, pos: Vector3, size_value: Vector3, color_value: Color, with_collision: bool = true) -> Node3D:
	var holder: Node3D
	if with_collision:
		holder = StaticBody3D.new()
	else:
		holder = Node3D.new()
	holder.name = node_name
	holder.position = pos
	parent.add_child(holder)
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size_value
	mesh_instance.mesh = box
	mesh_instance.material_override = _mat(color_value)
	holder.add_child(mesh_instance)
	if with_collision:
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size_value
		shape_node.shape = shape
		holder.add_child(shape_node)
	return holder

func _forward_down() -> void:
	move_forward = true
func _forward_up() -> void:
	move_forward = false
func _back_down() -> void:
	move_back = true
func _back_up() -> void:
	move_back = false
func _left_down() -> void:
	move_left = true
func _left_up() -> void:
	move_left = false
func _right_down() -> void:
	move_right = true
func _right_up() -> void:
	move_right = false
